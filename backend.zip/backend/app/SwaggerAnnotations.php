<?php

/**
 * @OA\Info(
 *     title="My API",
 *     version="1.0.0"
 * )
 */